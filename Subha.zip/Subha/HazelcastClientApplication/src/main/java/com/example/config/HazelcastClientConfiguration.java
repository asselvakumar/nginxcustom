package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;




@Configuration
public class HazelcastClientConfiguration {
 
    @Bean
    public ClientConfig hazelcastClientConfig() {
    	ClientConfig clientConfig = new ClientConfig();
//    	clientConfig.setClusterName("hazelcast-instance");
    	clientConfig.getNetworkConfig().addAddress("192.168.1.129:5701");
        return clientConfig;
//        		new ClientConfig().getGroupConfig()
//          .setClusterName("my-hazelcast-cluster")
//          .addAddress("192.168.1.129:5701");
    }
 
    @Bean
    public HazelcastInstance hazelcastInstance(ClientConfig clientConfig) {
        return HazelcastClient.newHazelcastClient(clientConfig);
    }
}

