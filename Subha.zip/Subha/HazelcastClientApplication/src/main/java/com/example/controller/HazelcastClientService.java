package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

@Service
public class HazelcastClientService {

	@Autowired
	private HazelcastInstance hazelcastInstance;

	public String getData() {
	  IMap<String, String> distributedMap = hazelcastInstance.getMap("my-distributed-map");
	  System.out.println("myMap -------" + distributedMap.get("key"));
	  return distributedMap.get("key");
	}

	public void setData(String value) {
	  IMap<String, String> distributedMap = hazelcastInstance.getMap("my-distributed-map");
	  distributedMap.put("key", value);
	}

}
