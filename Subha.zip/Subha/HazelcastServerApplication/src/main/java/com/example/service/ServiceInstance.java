package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

@RestController
public class ServiceInstance {
	
	@Autowired
	private HazelcastInstance hazelcastInstance;

	@GetMapping("/data")
	public String getData() {
	  IMap<String, String> distributedMap = hazelcastInstance.getMap("my-distributed-map");
	//  distributedMap.put("key", "value");
	  return distributedMap.get("key");
	}

	@PostMapping(value = "/put")
	public void setData(@RequestParam String value) {
	  IMap<String, String> distributedMap = hazelcastInstance.getMap("my-distributed-map");
	  distributedMap.put("key", value);
	}

}
