package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.MaxSizePolicy;
import com.hazelcast.config.NetworkConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;


@Configuration
public class HazelcastServerConfig {
 
    @Bean
    public Config hazelcastConfig() {
        Config config = new Config()
          .setInstanceName("hazelcast-instance")
          .addMapConfig(
            new MapConfig()
              .setName("my-distributed-map")
              .setTimeToLiveSeconds(20));
 
        NetworkConfig network = config.getNetworkConfig();
        network.setPort(5701).setPortAutoIncrement(true);
        JoinConfig join = network.getJoin();
 
        join.getTcpIpConfig().setEnabled(true)
          .addMember("192.168.1.100");
        join.getMulticastConfig().setEnabled(false);
 
        return config;
    }
}


